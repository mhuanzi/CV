# MCCANet

## Papers

## 1. Environment setup
This code has been tested on on the workstation with Intel Xeon Silver 4210R CPU and GPUs of NVIDIA GeForce RTX 3090 with a single 24G of video memory, Python 3.8, pytorch 1.11.

## 2. Download the datesets:
* iSAID:
[iSAID](https://captain-whu.github.io/iSAID/index.html)

and modify the dataset directory in the validation code.

## 3. Download the models (loading models):

* [models](https://drive.google.com/drive/folders/1lS8LjJLDTppROXrDUvCNKqbrsV6Xk-UF?usp=sharing)

and put it into log directory.

## 4. Train

    coming soon
    
## 5. Test

    python eval.py


## 6. Cite

